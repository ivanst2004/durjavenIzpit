﻿namespace Project_IT_kariera.Models
{
    public class Ticket
    {
        public int? Id { get; set; }
        public string? User { get; set; }
        public string? Event { get; set; }
        public DateTime Date { get; set; }
    }
}
